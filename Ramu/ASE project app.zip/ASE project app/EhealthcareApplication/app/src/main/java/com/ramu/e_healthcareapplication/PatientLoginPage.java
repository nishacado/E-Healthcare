package com.ramu.e_healthcareapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class PatientLoginPage extends AppCompatActivity {
    EditText Id, Pass;
    String Patient_id ="", Patient_pass="";
    Button btn_loginbutton;
    TextView tv_test;
    private String LoginUrl="http://fypemployeemanagementsystem.com/fypfiles/loginfiles/login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login_page);
        Id= (EditText)findViewById(R.id.patientUserId);
        Pass=(EditText)findViewById(R.id.patientPassword);
        btn_loginbutton = (Button) findViewById(R.id.patientLoginButton);
        tv_test= (TextView) findViewById(R.id.tv_test);
        btn_loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//              final DataHandler dataHandler = new DataHandler(getApplicationContext(),"employee",null,1);
                Patient_id = Id.getText().toString();
                Patient_pass = Pass.getText().toString();
//              int login = dataHandler.AuthenticateEmp(Emp_id);
//              if(login== 1 && Emp_pass.equals("pass123")){
//                Intent intent = new Intent(Emp_Auth.this, EmpDashboard.class);
//                intent.putExtra("emp_id", Emp_id);
//               startActivity(intent);
//              }
//              else{
//              Toast.makeText(this, "Incorrect User ID or Password", Toast.LENGTH_SHORT).show();
//              }
                loginChecker(LoginUrl, Patient_id,Patient_pass);

            }
        });

    }



    private void loginChecker(final String urlWebService, String Username, String Password) {

        class LoginChecker extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                try {
                    phpFeedback(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {

                String user_name = Username;
                String password = Password;

                try {
                    URL url = new URL(urlWebService);

                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoOutput(true);
                    con.setDoInput(true);
                    OutputStream outputStream = con.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    String post_data = URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(user_name,"UTF-8")+"&"
                            +URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8");
                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();

                    StringBuilder sb = new StringBuilder();

                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;

                    while ((json = bufferedReader.readLine()) != null) {

                        sb.append(json + "\n");
                    }
                    String result =sb.toString().trim();
                    return result;
                } catch (Exception e) {
                    return null;
                }

            }
        }

        LoginChecker loginChecker = new LoginChecker();
        loginChecker.execute();
    }

    private void phpFeedback(String json) throws JSONException {
        JSONObject jsonObject = new JSONObject(json);
        int success = jsonObject.getInt("success");
        String abc =success+"";
        tv_test.setText(abc);
        if(success==1){
            Intent intent = new Intent(PatientLoginPage.this, PatientDashboard.class);
            intent.putExtra("emp_id", Patient_id);
            startActivity(intent);
        }
    }
}