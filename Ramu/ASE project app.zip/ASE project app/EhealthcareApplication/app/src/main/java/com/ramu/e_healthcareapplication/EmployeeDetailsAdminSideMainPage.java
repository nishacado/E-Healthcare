package com.ramu.e_healthcareapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EmployeeDetailsAdminSideMainPage extends AppCompatActivity {

    Button btn_go_to_add_employee_details_page,btn_go_to_view_employee_details_page;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_details_admin_side_main_page);

        btn_go_to_add_employee_details_page= findViewById(R.id.btn_go_to_add_employee_details_page);
        btn_go_to_view_employee_details_page= findViewById(R.id.btn_go_to_view_employee_details_page);

        btn_go_to_add_employee_details_page.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmployeeDetailsAdminSideMainPage.this,EmployeeDetailsAdminSide.class);
                startActivity(intent);
            }
        });

        btn_go_to_view_employee_details_page.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmployeeDetailsAdminSideMainPage.this,EmployeeDetailsAdminSideViewPage.class);
                startActivity(intent);
            }
        });

    }
}