package com.ramu.e_healthcareapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminDashboard extends AppCompatActivity {
    Button btn_goToManageEmployee,btn_goToLeaveManagement,btn_goToPayrollMainPage,btn_goToPayrollHistoryPage,
            btn_goToShiftDetailsAdminSideMainPage, btn_goToAddShiftPage,btn_goToAttendanceCheckerPage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);
        btn_goToManageEmployee= findViewById(R.id.goToAddAndManageEmployeeDetailsAdminSide);

        btn_goToLeaveManagement= findViewById(R.id.goToLeaveManagementAdminSide);


        btn_goToShiftDetailsAdminSideMainPage = findViewById( R.id.goToShiftDetailsAdminSideMainPage);


        btn_goToManageEmployee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminDashboard.this, EmployeeDetailsAdminSideMainPage.class);
                startActivity(intent);
            }
        });

        btn_goToLeaveManagement.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminDashboard.this,LeaveManagementAdminSide.class);
                startActivity(intent);
            }
        });


        btn_goToShiftDetailsAdminSideMainPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboard.this,ShiftDetailsMainPage.class);
                startActivity(intent);
            }
        });

    }
}