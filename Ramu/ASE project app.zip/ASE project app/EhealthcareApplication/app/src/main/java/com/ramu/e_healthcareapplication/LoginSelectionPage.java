package com.ramu.e_healthcareapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LoginSelectionPage extends AppCompatActivity {
    Button btn_PatientSelectionButton, btn_EmployeeSelectionButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_selection_page);
        btn_PatientSelectionButton=findViewById(R.id.btn_goToPatientLoginPage);
        btn_EmployeeSelectionButton=findViewById(R.id.btn_goToEmployeeLoginPage);
        btn_EmployeeSelectionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginSelectionPage.this,EmployeeLoginTypeSelectionPage.class);
                startActivity(intent);
            }
        });

        btn_PatientSelectionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginSelectionPage.this,PatientLoginPage.class);
                startActivity(intent);
            }
        });
    }
}