package com.ramu.e_healthcareapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EmployeeDetailsAdminSide extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_details_admin_side);
    }
}