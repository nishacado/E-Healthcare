package com.ramu.e_healthcareapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PatientDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_dashboard);
    }
}