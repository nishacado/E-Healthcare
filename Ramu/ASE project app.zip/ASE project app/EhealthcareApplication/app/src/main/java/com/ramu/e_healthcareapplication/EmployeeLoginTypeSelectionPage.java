package com.ramu.e_healthcareapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EmployeeLoginTypeSelectionPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_login_type_selection_page);
    }
}