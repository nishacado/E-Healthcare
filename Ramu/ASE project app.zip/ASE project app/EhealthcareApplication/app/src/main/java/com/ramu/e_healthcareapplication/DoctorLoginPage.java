package com.ramu.e_healthcareapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DoctorLoginPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login_page);
    }
}